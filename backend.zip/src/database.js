// ============================================
// DATABASE SETUP - Firestore with CIA Triad Schema
// ============================================
// Confidentiality: emails encrypted, passwords hashed
// Integrity: HMAC on emails, hash integrity checks
// Availability: managed cloud datastore + app-level lockout/rate limit
// ============================================

const admin = require('firebase-admin');
const fs = require('fs');
const path = require('path');

let firestore = null;
let initialized = false;
let initPromise = null;

const COLLECTIONS = {
  users: 'users',
  pepperVersions: 'pepper_versions',
  auditLog: 'audit_log',
  parking: 'parking_locations',
};

function loadServiceAccountFromFile(serviceAccountPath) {
  const resolvedPath = path.isAbsolute(serviceAccountPath)
    ? serviceAccountPath
    : path.join(__dirname, '..', serviceAccountPath);

  if (!fs.existsSync(resolvedPath)) {
    throw new Error(`FIREBASE_SERVICE_ACCOUNT_PATH not found: ${resolvedPath}`);
  }

  return JSON.parse(fs.readFileSync(resolvedPath, 'utf8'));
}

function buildServiceAccountFromEnv() {
  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKey = process.env.FIREBASE_PRIVATE_KEY;

  if (!projectId || !clientEmail || !privateKey) {
    throw new Error(
      'Missing Firebase credentials. Set FIREBASE_SERVICE_ACCOUNT_PATH OR FIREBASE_PROJECT_ID + FIREBASE_CLIENT_EMAIL + FIREBASE_PRIVATE_KEY.'
    );
  }

  const normalizedPrivateKey = privateKey
    .replace(/^"|"$/g, '')
    .replace(/\r/g, '')
    .replace(/\\+n/g, '\n');

  return {
    projectId,
    clientEmail,
    privateKey: normalizedPrivateKey,
  };
}

function buildServiceAccountFromBase64() {
  const encoded = process.env.FIREBASE_SERVICE_ACCOUNT_BASE64;
  if (!encoded) return null;
  const json = Buffer.from(encoded, 'base64').toString('utf8');
  return JSON.parse(json);
}

function getFirestore() {
  if (firestore) {
    return firestore;
  }

  const serviceAccount =
    buildServiceAccountFromBase64() ||
    (process.env.FIREBASE_SERVICE_ACCOUNT_PATH
      ? loadServiceAccountFromFile(process.env.FIREBASE_SERVICE_ACCOUNT_PATH)
      : buildServiceAccountFromEnv());

  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      projectId:
        process.env.FIREBASE_PROJECT_ID ||
        serviceAccount.projectId ||
        serviceAccount.project_id,
    });
  }

  firestore = admin.firestore();
  return firestore;
}

async function ensureInitialized() {
  if (initialized) {
    return;
  }

  const db = getFirestore();
  const currentPepperSnapshot = await db
    .collection(COLLECTIONS.pepperVersions)
    .where('is_current', '==', true)
    .limit(1)
    .get();

  if (currentPepperSnapshot.empty) {
    await db.collection(COLLECTIONS.pepperVersions).doc('1').set({
      version: 1,
      is_current: true,
      created_at: new Date().toISOString(),
    });
  }

  initialized = true;
}

function ready() {
  if (!initPromise) {
    initPromise = ensureInitialized();
  }
  return initPromise;
}

async function getUserByEmailHmac(emailHmac) {
  await ready();
  const db = getFirestore();

  const snapshot = await db
    .collection(COLLECTIONS.users)
    .where('email_hmac', '==', emailHmac)
    .limit(1)
    .get();

  if (snapshot.empty) {
    return null;
  }

  const doc = snapshot.docs[0];
  const data = doc.data();
  return {
    ...data,
    id: data.id || doc.id,
  };
}

async function getUserById(userId) {
  await ready();
  const db = getFirestore();
  const doc = await db.collection(COLLECTIONS.users).doc(userId).get();

  if (!doc.exists) {
    return null;
  }

  const data = doc.data();
  return {
    ...data,
    id: data.id || doc.id,
  };
}

async function getUserByVerificationTokenHash(tokenHash) {
  await ready();
  const db = getFirestore();

  const snapshot = await db
    .collection(COLLECTIONS.users)
    .where('email_verification_token_hash', '==', tokenHash)
    .limit(1)
    .get();

  if (snapshot.empty) {
    return null;
  }

  const doc = snapshot.docs[0];
  const data = doc.data();
  return {
    ...data,
    id: data.id || doc.id,
  };
}

async function getUserByPasswordResetTokenHash(tokenHash) {
  await ready();
  const db = getFirestore();

  const snapshot = await db
    .collection(COLLECTIONS.users)
    .where('password_reset_token_hash', '==', tokenHash)
    .limit(1)
    .get();

  if (snapshot.empty) {
    return null;
  }

  const doc = snapshot.docs[0];
  const data = doc.data();
  return {
    ...data,
    id: data.id || doc.id,
  };
}

async function setUserEmailVerificationToken(userId, tokenHash, expiresAt) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).update({
    email_verification_token_hash: tokenHash,
    email_verification_expires_at: expiresAt,
    updated_at: new Date().toISOString(),
  });
}

async function markUserEmailVerified(userId) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).update({
    email_verified: true,
    email_verified_at: new Date().toISOString(),
    email_verification_token_hash: null,
    email_verification_expires_at: null,
    updated_at: new Date().toISOString(),
  });
}

async function setUserPasswordResetToken(userId, tokenHash, expiresAt, requestDate, requestCount) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).update({
    password_reset_token_hash: tokenHash,
    password_reset_expires_at: expiresAt,
    password_reset_requested_at: new Date().toISOString(),
    password_reset_request_date: requestDate,
    password_reset_request_count: requestCount,
    updated_at: new Date().toISOString(),
  });
}

async function clearUserPasswordResetToken(userId) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).update({
    password_reset_token_hash: null,
    password_reset_expires_at: null,
    updated_at: new Date().toISOString(),
  });
}

async function createUser(user) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(user.id).set(user);
}

async function updateUserProfile(userId, updates) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).set({
    ...updates,
    updated_at: new Date().toISOString(),
  }, { merge: true });
}

async function addOAuthProviderToUser(userId, provider) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).set({
    auth_provider: provider,
    auth_providers: admin.firestore.FieldValue.arrayUnion(provider),
    updated_at: new Date().toISOString(),
  }, { merge: true });
}

async function deleteUser(userId) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).delete();
}

async function setBannedStatus(userId, banned) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).update({
    banned: banned,
    updated_at: new Date().toISOString(),
  });
}

async function getCurrentPepperVersion() {
  await ready();
  const db = getFirestore();

  const snapshot = await db
    .collection(COLLECTIONS.pepperVersions)
    .where('is_current', '==', true)
    .limit(1)
    .get();

  if (snapshot.empty) {
    return { version: 1 };
  }

  return snapshot.docs[0].data();
}

async function updateUserFailedLogin(userId, attempts, lockUntil) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).update({
    login_attempts: attempts,
    locked_until: lockUntil,
    updated_at: new Date().toISOString(),
  });
}

async function updateUserLoginAttempts(userId, attempts) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).update({
    login_attempts: attempts,
    updated_at: new Date().toISOString(),
  });
}

async function updateUserPasswordHashAndPepperVersion(userId, passwordHash, pepperVersion) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).update({
    password_hash: passwordHash,
    pepper_version: pepperVersion,
    updated_at: new Date().toISOString(),
  });
}

async function resetUserLockout(userId) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).update({
    login_attempts: 0,
    locked_until: null,
    updated_at: new Date().toISOString(),
  });
}

async function addAuditLog({ user_id = null, action, ip_address = null, details = null }) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.auditLog).add({
    user_id,
    action,
    ip_address,
    details,
    created_at: new Date().toISOString(),
  });
}

async function getMaxPepperVersion() {
  await ready();
  const db = getFirestore();
  const snapshot = await db
    .collection(COLLECTIONS.pepperVersions)
    .orderBy('version', 'desc')
    .limit(1)
    .get();

  if (snapshot.empty) {
    return { version: 0 };
  }

  return snapshot.docs[0].data();
}

async function rotatePepperVersion(newVersion) {
  await ready();
  const db = getFirestore();
  const batch = db.batch();

  const currentSnapshot = await db
    .collection(COLLECTIONS.pepperVersions)
    .where('is_current', '==', true)
    .get();

  currentSnapshot.forEach((doc) => {
    batch.update(doc.ref, { is_current: false });
  });

  const newVersionRef = db.collection(COLLECTIONS.pepperVersions).doc(String(newVersion));
  batch.set(newVersionRef, {
    version: newVersion,
    is_current: true,
    created_at: new Date().toISOString(),
  });

  await batch.commit();
}

async function countUsersWithPepperVersionLessThan(version) {
  await ready();
  const db = getFirestore();
  const snapshot = await db
    .collection(COLLECTIONS.users)
    .where('pepper_version', '<', version)
    .get();
  return snapshot.size;
}

async function getAllUsers() {
  await ready();
  const db = getFirestore();
  const snapshot = await db
    .collection(COLLECTIONS.users)
    .orderBy('created_at', 'desc')
    .get();
  return snapshot.docs.map((doc) => {
    const d = doc.data();
    return {
      id: doc.id,
      first_name: d.first_name || '',
      last_name: d.last_name || '',
      role: d.role || 'driver',
      email_verified: d.email_verified !== false,
      banned: d.banned === true,
      created_at: d.created_at || null,
      updated_at: d.updated_at || null,
      auth_providers: d.auth_providers || (d.auth_provider ? [d.auth_provider] : []),
    };
  });
}

async function getRecentLoginLogs(limitCount = 100) {
  await ready();
  const db = getFirestore();
  // Avoid composite index requirement by filtering action in JS after fetching
  const snapshot = await db
    .collection(COLLECTIONS.auditLog)
    .orderBy('created_at', 'desc')
    .limit(500)
    .get();
  const loginActions = new Set(['LOGIN_SUCCESS', 'OAUTH_LOGIN_SUCCESS']);
  return snapshot.docs
    .map((doc) => {
      const d = doc.data();
      return {
        id: doc.id,
        user_id: d.user_id || null,
        action: d.action,
        ip_address: d.ip_address || null,
        created_at: d.created_at || null,
      };
    })
    .filter((d) => loginActions.has(d.action))
    .slice(0, limitCount);
}

// ---- SAVED ROUTES (per-user subcollection) ----

async function getSavedRoutes(userId) {
  await ready();
  const db = getFirestore();
  const snapshot = await db
    .collection(COLLECTIONS.users).doc(userId)
    .collection('saved_routes')
    .orderBy('saved_at', 'desc')
    .limit(10)
    .get();
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
}

async function saveRoute(userId, route) {
  await ready();
  const db = getFirestore();
  const colRef = db.collection(COLLECTIONS.users).doc(userId).collection('saved_routes');
  const existing = await colRef.get();
  if (existing.size >= 10) {
    throw Object.assign(new Error('Saved route limit reached.'), { code: 'LIMIT_REACHED' });
  }
  const doc = await colRef.add({ ...route, saved_at: new Date().toISOString() });
  return doc.id;
}

async function deleteSavedRoute(userId, routeId) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.users).doc(userId).collection('saved_routes').doc(routeId).delete();
}

// ── Parking Locations ──────────────────────────────────────────────────────────

async function getAllParkingLocations() {
  await ready();
  const db = getFirestore();
  const snapshot = await db.collection(COLLECTIONS.parking).orderBy('added_at', 'desc').get();
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
}

async function addParkingLocation({ name, type, lat, lng, notes, addedBy }) {
  await ready();
  const db = getFirestore();
  const doc = await db.collection(COLLECTIONS.parking).add({
    name,
    type,
    lat,
    lng,
    notes: notes || '',
    added_by: addedBy,
    added_at: new Date().toISOString(),
  });
  return doc.id;
}

async function updateParkingLocation(id, updates) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.parking).doc(id).update(updates);
}

async function deleteParkingLocation(id) {
  await ready();
  const db = getFirestore();
  await db.collection(COLLECTIONS.parking).doc(id).delete();
}

module.exports = {
  ready,
  getUserById,
  getUserByEmailHmac,
  getUserByVerificationTokenHash,
  getUserByPasswordResetTokenHash,
  createUser,
  updateUserProfile,
  addOAuthProviderToUser,
  deleteUser,
  setUserEmailVerificationToken,
  setUserPasswordResetToken,
  clearUserPasswordResetToken,
  markUserEmailVerified,
  getCurrentPepperVersion,
  updateUserFailedLogin,
  updateUserLoginAttempts,
  updateUserPasswordHashAndPepperVersion,
  resetUserLockout,
  addAuditLog,
  getMaxPepperVersion,
  rotatePepperVersion,
  countUsersWithPepperVersionLessThan,
  getAllUsers,
  getRecentLoginLogs,
  setBannedStatus,
  getSavedRoutes,
  saveRoute,
  deleteSavedRoute,
  getAllParkingLocations,
  addParkingLocation,
  updateParkingLocation,
  deleteParkingLocation,
};
